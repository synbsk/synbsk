---
author: Hugo Authors
title: Series Part 2
date: 2021-08-15
description: A brief guide to how to setup series part 2
series:
  - series-setup
---

In this second part of the series we'll show you where to find the full series

<!--more-->

When you created a series, you'll probably want to link to the full set of blogposts.  
In this example we used `series-setup` as our series name.

This means we can now go to `http://localhost:1313/series/series-setup/` to see all the blog posts of this serie.
